import 'dart:convert';
import 'package:get/get.dart';
import 'package:googletracking_project/core/apiservice.dart';
import 'package:googletracking_project/model/entrydetailmodel.dart';

class EntryController extends GetxController {
  List<MovieDetails> products = [];
  var isDataLoading = false.obs;

  @override
  void onInit() {
    getProduct();
    print("data get value");
    super.onInit();
  }

  getProduct() {
    getsubNews().then((value) {
      print("Here comess:$isDataLoading");
      products = List<Map<String, dynamic>>.from(value["feed"]["entry"])
          .map((e) => MovieDetails.fromJson(e))
          .toList();
      print("Here comess:$isDataLoading");
      isDataLoading(true);
    });
  }
}
