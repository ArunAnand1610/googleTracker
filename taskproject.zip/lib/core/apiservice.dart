
import 'package:googletracking_project/core/networkutils.dart';
import 'package:http/http.dart' as http;

import 'dart:async';



Future getsubNews() async {
  var url =
     "https://itunes.apple.com/in/rss/topalbums/limit=25/json";
  return handleResponse(await http.get(
    Uri.parse(url),
   
  ));
  
}


