import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:googletracking_project/getxcontrollers/profilecontroller.dart';
import 'package:googletracking_project/model/usermodel.dart';
import 'package:googletracking_project/pages/entrydetails.dart';
import 'package:googletracking_project/pages/profilepage.dart';

import 'package:nb_utils/nb_utils.dart';

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  @override
  Widget build(BuildContext context) {
    final Controller = Get.put(ProfileController());
    return SafeArea(
        child: DefaultTabController(
            // Added
            length: 2, // Added
            initialIndex: 0,
            child: Scaffold(
                appBar: PreferredSize(
                  preferredSize: Size.fromHeight(48),
                  child: Container(
                    height: 48,
                    width: double.infinity,
                    color: const Color.fromRGBO(40, 115, 240, 1),
                    child: Container(
                      margin: const EdgeInsets.only(right: 16),
                      child: Row(
                        // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          IconButton(
                              onPressed: () {
                                Get.back();
                              },
                              icon: const Icon(
                                Icons.arrow_back,
                                color: Colors.white,
                                size: 28,
                              )),
                          const Padding(
                            padding: EdgeInsets.only(left: 56.0),
                            child: Text(
                              "Home Page",
                              style: TextStyle(
                                  fontFamily: "Gortita",
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white),
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                ),
                key: _scaffoldKey,
                body: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                  Container(
                    // color: Colors.amberAccent,
                    margin: const EdgeInsets.only(top: 24, bottom: 24),
                    height: 32,
                    width: double.infinity,
                    child: TabBar(
                        indicatorColor: Color(0xff007ebc),
                        labelColor: Color(0xff007ebc),
                        unselectedLabelColor: Color(0xff222222),
                        indicatorSize: TabBarIndicatorSize.tab,
                        labelStyle: const TextStyle(
                            fontFamily: "Gortita",
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Colors.blueAccent),
                        tabs: [
                          const Tab(
                              child: Text(
                            'Homework',
                          )),
                          Container(
                            width: 130,
                            child: const Tab(
                                child: Text(
                              'Profile',
                              // style: TextStyle(
                              //     fontSize:
                              //         11.2) //color: Color(0xff787878),
                            )),
                          ),
                        ]),
                  ),
                  Expanded
                  (
                    child: Container(
                        height: MediaQuery.of(context).size.height,
                        margin: const EdgeInsets.only(
                            right: 16, left: 16, top: 16),
                        color: Colors.white,
                        child: const TabBarView(
                          children: [
                            EnetrDetails(),
                            ProfilePage(),
                          ],
                        )),
                  ),
                  SizedBox(
                    height: 40,
                  )
                ]))));
  }
}
