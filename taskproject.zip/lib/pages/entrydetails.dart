import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:googletracking_project/getxcontrollers/entrycontroller.dart';

class EnetrDetails extends StatefulWidget {
  const EnetrDetails({super.key});

  @override
  State<EnetrDetails> createState() => _EnetrDetailsState();
}

class _EnetrDetailsState extends State<EnetrDetails> {
  //final EntryController dataController = Get.find();
   final dataController = Get.put(EntryController());
  @override
  Widget build(BuildContext context) {
    print("object${dataController.products.length}");
    return Obx(() => dataController.isDataLoading.value == false
        ? Padding(
            padding:
                EdgeInsets.only(top: MediaQuery.of(context).size.height / 9),
            child: const Center(child: CircularProgressIndicator()),
          )
        : ListView.builder(
            itemCount: dataController.products.length,
            shrinkWrap: true,
            physics: ClampingScrollPhysics(),
            itemBuilder: (context, index) {
              final user = dataController.products[index];
              return Padding(
                padding: const EdgeInsets.only(top:16.0),
                child: Card(
                  color: Color(0xffF8F8F8),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "${user.imName!.label}",
                            style: GoogleFonts.rubik(
                              fontSize: 12,
                              fontWeight: FontWeight.w500,
                              color: const Color(0xff000000),
                            ),
                          ),
                          Row(
                            children: [
                              Container(
                                // color: Colors.brown.shade300,
                                height: 75,
                                  
                                child: ListView.builder(
                                  scrollDirection: Axis.horizontal,
                                  shrinkWrap: true,
                                  physics: NeverScrollableScrollPhysics(),
                                  itemCount:dataController.products[index].imImage.length,
                                  itemBuilder: (context, i) {
                                    return Padding(
                                      padding: const EdgeInsets.only(left:12.0),
                                      child: Container(
                                        height: 65,
                                        width: 65,
                                        child: Image.network(
                                          '${user.imImage[i].label}',
                                          fit: BoxFit.contain,
                                        ),
                                      ),
                                    );
                                  },
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    )),
              );
            }));
  }
}
