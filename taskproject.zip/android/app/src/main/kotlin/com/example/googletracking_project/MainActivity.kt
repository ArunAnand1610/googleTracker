package com.example.googletracking_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
